import numpy as np
import pandas as pd
from CoolProp.CoolProp import PropsSI

def generate_dataset(fluid, T_min, T_max, P_min, P_max, filename):

    T_values = np.linspace(T_min, T_max, 50)
    P_values = np.linspace(P_min, P_max, 50)

    data = []

    for T in T_values:
        for P in P_values:
            try:
                rho = PropsSI("D", "T", T, "P", P, fluid)
                data.append([T, P, rho])
            except:
                continue

    df = pd.DataFrame(data, columns=[
        "Temperature (K)",
        "Pressure (Pa)",
        "Density (kg/m^3)"
    ])

    df.to_csv(filename, index=False)
    print(f"{filename} created successfully.")


# Methane
generate_dataset(
    "Methane",
    120, 350,
    5e5, 8e6,
    "methane_dataset.csv"
)

# R134a
generate_dataset(
    "R134a",
    250, 420,
    2e5, 6e6,
    "r134a_dataset.csv"
)
